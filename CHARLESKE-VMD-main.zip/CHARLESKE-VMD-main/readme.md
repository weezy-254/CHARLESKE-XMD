<a href="https://gig.io/typing-svg"><img src="https://readme-typing-svg.demolab.com?font=Black+Ops+One&size=100&pause=1000&color=FF0000&center=true&width=1000&height=100&lines=CHARLESKE-VMD" alt="Typing SVG" /><

<p align="center">  
  <a href="https://files.catbox.moe/n6dmx3.jpeg">
    <img alt="secktor docs" height="300" src="https://files.catbox.moe/n6dmx3.jpeg">
    <h1 align="center"> 
    </h1>
  </a>
</p>  

---


<p align="center">
  <a href="https://github.com/charleske"><img title="Author" src="https://img.shields.io/badge/charleske-black?style=for-the-badge&logo=Github"></a> 
  <a href="https://whatsapp.com/channel/0029VaZuGSxEawdxZK9CzM0Y"><img title="Channel" src="https://img.shields.io/badge/CHANNEL-black?style=for-the-badge&logo=whatsapp"></a> 
  <a href="https://wa.me/254759626063"><img title="Chat" src="https://img.shields.io/badge/CHAT US-neon?style=for-the-badge&logo=whatsapp"></a>
</p>

<p align="center">
<p align="center">
  <a href="https://github.com/charleskenya1?tab=followers"><img title="1000Followers" src="https://img.shields.io/github/followers/charleskenya1?label=Followers&style=social"></a>
  <a href="https://github.com/charleskenya1/BMW-MD/stargazers/"><img title="Stars" src="https://img.shields.io/github/stars/charleskenya1/BMW-MD?&style=social"></a>
  <a href="https://github.com/charleske/BMW-MD/network/"><img title="Forks" src="https://img.shields.io/github/forks=/charleskenya1CHARLESKE/BMW-MD?style=social"></a>
  <a href="https://github.com/charleskenya1/BMW-MD/watchers"><img title="Watching" src="https://img.shields.io/github/watchers/charleskenya1/BMW-MD?label=Watching&style=social"></a>
</p>

---

## 🚀 GET SESSION

<p align="center">
  <a href="https://charle-ke.onrender.com">
    <img title="GET SESSION" src="https://img.shields.io/badge/GET SESSION-neonred?style=for-the-badge&logo=charleske" width="220" height="38.45"/>
  </a>
</p>

---

## 🧚‍♂️ CHARLESKE'S DEPLOYMENT OPTIONS

### 🔹 DEPLOY ON HEROKU

  [![Click Here](https://img.shields.io/badge/➤Click-Here-red.svg)](https://charleskenyaverification-1.vercel.app/)

##### 🔹 DEPLOY ON RAILWAY 
[![Click Here](https://img.shields.io/badge/➤Click-Here-white.svg)](https://railway.com?referralCode=usJR_h)
  
  
### 🔹 DEPLOY ON OTHER PLATFORMS👇

- **Render:**  
  [![Click Here](https://img.shields.io/badge/➤Click-Here-black.svg)](https://render.com)

- **ToyStack:**  
  [![Click Here](https://img.shields.io/badge/➤Click-Here-white.svg)](https://toystack.ai)

- **Koyeb:**  
  [![Click Here](https://img.shields.io/badge/➤Click-Here-green.svg)](https://koyeb.com)

- **TALKDROVE:**

   [![Click Here](https://img.shields.io/badge/➤Click-Here-white.svg)](https://host.talkdrove.com/auth/signup?ref=7D90F312)

- **SUPPORT:**  
  [![Click Here](https://img.shields.io/badge/➤Click-Here-neon.svg)](https://charleske-surpot.vercel.app/)
